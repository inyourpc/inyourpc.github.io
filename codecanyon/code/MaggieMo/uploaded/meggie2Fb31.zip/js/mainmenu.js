if(NoesGames == null){	var NoesGames = {};}

NoesGames.mainmenuState = function(game){
	//var lokal disini
}

NoesGames.mainmenuState.prototype = {
    init: function(){
		// reset var lokal disini
		this.group_menu =null;
		this.group_warning= null;
	  	this.flag_debug = flag_debug;
	  	this.flag_tween = false;
		this.filter = null;
	},
    
	create: function(){
		saveLoadData(2);
		if(this.flag_debug)
		    game.time.advancedTiming = true;
	
		//if(game.device.desktop)
		//{
		  if(bgm.isPlaying == false)
  		    callAudio(bgm,true,0.7);
		  else
		    callFadeToAudio(bgm,1000,0.7);		  		
		//}		
		this.initMenu();
		this.initCredit();
		this.initWarning();
	},
	
	addButton : function (group, button, x, y, name, nameImage, anchorx, anchory, scale){
		button = game.add.button( x, y, "sprites_game", this.buttonPress, this, nameImage+".png", nameImage+".png", nameImage+".png");
		button.name = name;
		button.scale.setTo(scale);
		button.anchor.setTo(  anchorx, anchory );
		if(group != null)
		  group.add(button);
		return button;
	},

	addSprite : function (group, sprite, x, y,  name, anchorx, anchory ){
		sprite = game.add.sprite( x, y, "sprites_game");
		sprite.frameName = name+".png";
		sprite.anchor.setTo(  anchorx, anchory );
		if(group != null)
			group.add(sprite);
		return sprite;
	},

	addBitMapText : function(group, text, x, y, isiText, font, size, anchorx, anchory ){		
		text = game.add.bitmapText( x, y, font, "", ratioXY(size));
		text.anchor.setTo(anchorx, anchory);
		text.text = isiText;
		if(group != null)
			group.add(text);		
	    return text;
	},	

	addTween : function( button, tipeTween, buttonAlpha, buttonx, buttony, delay, efek, predelay){
		if (tipeTween==1)
			return game.add.tween( button ).from( { x : buttonx, y: buttony, alpha : buttonAlpha }, delay, efek , true, predelay, 0, false);
		else
			return game.add.tween( button ).to( { x : buttonx, y: buttony, alpha : buttonAlpha }, delay, efek , true, predelay, 0, false);
	},
	
	buttonPress : function(button, pointer, isOver){
		if(isOver)
		{
			if(button.name == "soundbtn"){
				callAudio(sfx_klik,false,1);
				global_sound(button);
			}else if(button.name == "morebtn" || button.name == "FOG"){
				callAudio(sfx_klik,false,1);
				window.open('http://www.freeonlinegames.com');
			}else{
				if (!this.flag_tween){
					callAudio(sfx_klik,false,1);
					if(button.name == "playbtn"){
						
						console.log("showingbanner");
						//gdsdk.showBanner();	

						game.camera.flash(0xffffff,500);
						flag_tutor=false;
						level=curlevel;
						game.state.start('game');
					}else if(button.name == "creditbtn"){
						this.tweencredit(1);
					}else if(button.name == "tutorialbtn"){
						game.camera.flash(0xffffff,500);
						flag_tutor=true;
						level=1;
						game.state.start('game');						
					}else if(button.name == "resetbtn"){
						this.group_warning.visible=true;
					}else if(button.name == "nobtn"){
						this.group_warning.visible=false;
					}else if(button.name == "yesbtn"){
						saveLoadData(3);
						this.group_warning.visible=false;
					}else if(button.name == "filter1"){
						this.tweencredit(0);
					}
				}
			}
		}
	},

	pickObject: function(pickOpt, group, sprite, x, y, name, nameImage, anchorx, anchory){
		if (pickOpt==0)
			return this.addSprite(group, sprite, x, y, nameImage, anchorx, anchory);
		else
		if (pickOpt==1)
			return this.addButton(group, sprite, x, y, name, nameImage, anchorx, anchory,1);
		else
			return this.addBitMapText(group, sprite, x, y, nameImage, "blue_font", 30, 0.5, 0.5);
	},

	initMenu : function(){
		game.camera.flash(0xffffff,500);
		this.group_menu = game.add.group();
		var arrx = [480,280,700, 280,140,280, 420,900,140,60,900];
		var arry = [320,120,340, 345,430,500, 430,570,430,570,70];
		var pickOpt = [0,0,0,1,1,1,1,1,1,1,1];
		var name = ["","","","playbtn","morebtn","creditbtn","tutorialbtn","resetbtn","ratebtn","sharebtn","soundbtn"];
		var nameImage = ["menu_bg","title","char","play","moregames","credit","tutorial","reset","rate","share","sound_on"];
		for (var i=0;i<11;i++){
			var obj = this.pickObject(pickOpt[i], this.group_menu, obj, ratioXY(arrx[i]),ratioXY(arry[i]), name[i], nameImage[i], 0.5,0.5);
			if(i==4 || i==5 || i==6 || i==7 || i==8|| i==9 || i==10)//
				obj.scale.setTo(0.6);
			if( i==8|| i==9)//rate-share
				obj.visible=false;
			if(i==10){ //sound
				global_sound_change(obj);
			}
		}
		
		var FOG = game.add.button(0,game.world.height-20,"logo2",this.buttonPress,this,0,0,0);
		FOG.anchor.setTo(0,1);
		FOG.name = "FOG";
		this.group_menu.add(FOG);
		
		this.group_menu.visible=true;
		this.tweenMenu(1);
	},

	setxyObject: function(obj, x, y){
		obj.x = ratioXY(x);
		obj.y = ratioXY(y);
		obj.alpha = 1;
		return obj;
	},

	reinitMenu: function(){
		var arrx = [480,280,700, 280,140,280, 420,900,140,60,900];
		var arry = [320,120,340, 345,430,500, 430,570,430,570,70];
		for (var i=0;i<11;i++)
			this.group_menu.children[i] = this.setxyObject(this.group_menu.children[i], arrx[i], arry[i]);
	},

	tweenMenu: function(direction){
		game.camera.flash(0xffffff,500);
		var max_duration = direction==0? 3000:0;
		this.flag_tween=true;
		var deltax = [0,100, 0,50,0, -50,0,50,0,0];
		var deltay = [-100,0, -100,-50,-100, -50,100,-50,100,-100 ];
		var delay = [1000,0, 2000,2500,2750, 3000,3000,2500,3000,3000];
		var duration = [1000,1000, 1000,1000,1000, 1000,1000,1000,1000,1000];
		var efek = [Phaser.Easing.Quadratic.Out,Phaser.Easing.Quadratic.Out,Phaser.Easing.Quadratic.Out, 
					Phaser.Easing.Quadratic.Out,Phaser.Easing.Quadratic.Out,Phaser.Easing.Quadratic.Out,
					Phaser.Easing.Quadratic.Out,Phaser.Easing.Quadratic.Out,Phaser.Easing.Quadratic.Out,
					Phaser.Easing.Quadratic.Out];
		for (var i=1;i<11;i++)
			this.addTween(this.group_menu.children[i], direction, 0, this.group_menu.children[i].x+ratioXY(deltax[i-1]),this.group_menu.children[i].y+ratioXY(deltay[i-1]), duration[i-1], efek[i-1], Math.abs(max_duration-delay[i-1]));
		if (direction==1)
			var twn =this.addTween(this.group_menu.children[0] , direction, 1, this.group_menu.children[0].x,this.group_menu.children[0].y, 1000, "Linear", Math.abs(max_duration-1500));
		twn.onComplete.addOnce(function(){
			this.flag_tween=false;
			game.add.tween(this.group_menu.children[3].scale).to({x:0.8, y:0.8},1000,"Linear",true,0,-1,true);
			if (direction==1){ 
			}else{
			}	
		},this);
	},

	reinitcredit: function(){
		this.filter.visible=false;
		this.filter.alpha=1;
	},

	initCredit : function(){
		//add black filter
		this.filter = game.add.button(0,0,"bg_credit", this.buttonPress, this);
		this.filter.name = "filter1";		
		this.filter.anchor.setTo(0);
		this.filter.scale.setTo(1);
		//this.filter.inputEnabled = true;
		this.filter.alpha=1;
		this.filter.visible=false;
	},	

	tweencredit: function(direction){
		var max_duration = direction==0? 500:0;
		this.flag_tween=true;
		this.filter.visible=true;
		if (direction==1){
			var twn_credit =this.addTween(this.filter , direction, 0, this.filter.x,this.filter.y, 500, "Linear", Math.abs(max_duration-0));
		}else{
			var twn_credit =this.addTween(this.filter , direction, 0, this.filter.x,this.filter.y, 500, "Linear", Math.abs(max_duration-0));
		}
		twn_credit.onComplete.addOnce(function(){
			this.flag_tween=false;
			if (direction==1){ 
			}else{
				this.reinitcredit();
			}	
		},this);
	},

	initWarning: function(){
		this.group_warning= game.add.group();
		var bg = game.add.sprite(ratioXY(0),ratioXY(0),"filter");
		bg.inputEnabled=true;
		this.group_warning.add(bg);

		var arrx = [480,410, 550];
		var arry = [320,400, 400];
		var pickOpt = [0,1,1];
		var name = ["", "yesbtn","nobtn"];
		var nameImage =  ["paper", "yes","no"];
		for (var i=0;i<3;i++){
			var obj = this.pickObject(pickOpt[i], this.group_warning, obj, ratioXY(arrx[i]),ratioXY(arry[i]), name[i], nameImage[i], 0.5,0.5);
			if(i==0)
				obj.scale.setTo(0.8);
			if(i==1 || i==2)
				obj.scale.setTo(0.7);
		}
		var text= this.addBitMapText(this.group_warning, text, ratioXY( 480 ), ratioXY( 90 ), 'Warning', "grobold", 30, 0.5, 0.5);
		var text= this.addBitMapText(this.group_warning, text, ratioXY( 480 ), ratioXY( 230 ), 'Do you want to remove all saved data ?', "grobold", 26, 0.5, 0.5);
		text.maxWidth = ratioXY(320);
		text.align = 'center';
		this.group_warning.visible=false;
	},
};