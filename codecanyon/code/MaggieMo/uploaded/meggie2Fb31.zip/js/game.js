if(NoesGames == null){	var NoesGames = {};}

NoesGames.gameState = function(game){
  //var lokal disini
}

NoesGames.gameState.prototype = {
	
    init: function(){
		// reset var lokal disini
		this.group_button = null;
		this.group_meja = null;
		this.group_pause = null;
		this.group_tutor=null;
		this.group_result = null;
		this.group_ending = null;

	  	this.flag_debug = flag_debug;
	  	this.flag_tween = false;
		
		this.chars = null;

		this.filter_bg = null;

		this.text_score=null;
		this.text_jam=null;
		this.text_close=null;
		this.ingredients = null;
		this.name_ing = ['balon','gelas1','gelas2','piring','roti1', 'roti2','roti3','astor','kentang','roti_topping1', 'roti_topping2'];
		this.scale_ing= [2.7,0.75,0.75,1.8,1.6, 1.4,1,1,1,1.8, 1.8];

		this.dragSprite =null;
		this.spotOverlap =null;
		this.flag_drag =false;
		this.trashbtn=null;

		this.customers = null;
		this.hatis = null;
		this.name_cust = ['char1','char2','char3','char4','char5'];
		this.tipeCust = [
			[0],[0,1],[0,1],[0,1,2], 
			[0,1,2],[0,1,2,3],[0,1,2,3],[0,1,2,3,4]
		];

		this.maxcd_spawn = [400,375,350,325, 300,275,250,225];
		this.cd_spawn = Array.from(this.maxcd_spawn);//copy array
		
		this.maxcd_hati = [400,350,300,250,200];
		this.cd_hati = Array.from(this.maxcd_hati);//copy array
		
		this.maxcd_balon = [100,100,100,100, 100,100,100,100];
		this.cd_balon = Array.from(this.maxcd_balon);//copy array
		
		this.maxScore = [150,250,400,500, 650,950,1150,1300];
		this.curScore = 0;
		this.incScore = 10;

		this.minRequest=[1,1,1,2, 1,2,3,4];
		this.maxRequest=[1,2,3,3, 4,4,4,5];

		this.balons0 = null;
		this.balons1 = null;
		this.balons2 = null;
		this.balons3 = null;

		this.max_gametime = [ 3600, 3600+1800, 3600+1800*2, 3600+1800*3, 3600+1800*4, 3600+1800*5, 3600+1800*6, 3600+1800*7];
        this.game_time = this.max_gametime[level-1];
		this.menit = 0;
		this.detik = 0;
		this.str_detik = "";
		this.str_menit = "";

		this.result1 = null;
		this.result2 = null;
		this.result3 = null;
		this.result4 = null;
		this.result5 = null;
		this.result6 = null;

		this.totalCustomer=0;
		this.customerServed=0;
		this.bonus=0;
		this.bonusInc =5;

		this.ending1 = null;
		this.ending2 = null;
		this.ending3 = null;
		this.ending4 = null;

		this.animCoin = null;

		this.timeTutor =16;
		this.text_tutor =null;
		this.arr_tutor =['Welcome to Tutorial Meggie Bread Rush','Click the breads to put it on the plate','Dump the bread if not match the order','Choose the match breads','Bring the order to the customer','Well done. Now lets begin the game'];
		//this.idx_dialog=1; //1-2
		//running dialog
	  	this.timeline =16;
		this.line = [];
		this.wordIndex = 0;
		this.lineIndex = 0;
		this.wordDelay = 10;//120;
		this.lineDelay = 500;
		this.texts = '';
		//skip dialog
		this.isTalk  = false;
		this.timeEvents = [];
	},
	
	create: function(){
		if(this.flag_debug)
		    game.time.advancedTiming = true;
		//if(game.device.desktop){
		  if(bgm.isPlaying == false)
  		    callAudio(bgm,true,0.3);
		  else
		    callFadeToAudio(bgm,1000,0.7);	  		
		//}
		this.initGame();
	},

	addButton : function (group, button, x, y, name, nameImage, anchorx, anchory){
		button = game.add.button( x, y, "sprites_game", this.buttonPress, this, nameImage+".png", nameImage+".png", nameImage+".png");
		button.name = name;
		button.anchor.setTo(  anchorx, anchory );
		if(group != null)
		  group.add(button);
		return button;
	},

	addSprite : function (group, sprite, x, y,  name, anchorx, anchory ){
		sprite = game.add.sprite( x, y, "sprites_game");
		sprite.frameName = name+".png";
		sprite.anchor.setTo(  anchorx, anchory );
		if(group != null)
			group.add(sprite);
		return sprite;
	},

	addBitMapText : function(group, text, x, y, isiText, font, size, anchorx, anchory ){		
		text = game.add.bitmapText( x, y, font, "", ratioXY(size));
		text.anchor.setTo(anchorx, anchory);
		text.text = isiText;
		if(group != null)
			group.add(text);		
	    return text;
	},	

	addTween : function( button, tipeTween, buttonAlpha, buttonx, buttony, delay, efek, predelay){
		if (tipeTween==1)
			return game.add.tween( button ).from( { x : buttonx, y: buttony, alpha : buttonAlpha }, delay, efek , true, predelay, 0, false);
		else
			return game.add.tween( button ).to( { x : buttonx, y: buttony, alpha : buttonAlpha }, delay, efek , true, predelay, 0, false);
	},

	buttonPress : function(button, pointer, isOver){
		if(isOver)
		{
			if(button.name == "soundbtn"){
				callAudio(sfx_klik,false,1);
				global_sound(button);
			}else if(button.name == "morebtn" || button.name == "FOG"){
				callAudio(sfx_klik,false,1);
				window.open('http://www.freeonlinegames.com');
			}else{
				if (!this.flag_tween){
					callAudio(sfx_klik,false,1);

					if(button.name == "menubtn"){
						callAudio(sfx_klik,false,1);
						game.state.start("mainmenu");
					}else if(button.name == "tutorbtn"){
						this.nextAnim();
					}else if(button.name == "playbtn"){
						callAudio(sfx_klik,false,1);
						game.state.start("game");
					}else if(button.name == "retrybtn" || button.name =="replaybtn"){
						callAudio(sfx_klik,false,1);
						game.state.start("game");
					}else if(button.name == "nextbtn" ){
						if (level<maxlevel){
							level++;
							curlevel = level;
							saveLoadData(1);
							game.state.start("game");
						}else{
							//reset level
							level=1;
							curlevel = level;
							saveLoadData(1);
							this.group_ending.visible=true;
							this.tweenEnding(1);
						}
					}else if(button.name == "pausebtn"){
						this.group_pause.visible=true;
						this.tweenPause(1);
					}else if(button.name == "resumebtn"){
						this.group_pause.visible=false;
					}else{
						//ambil ingredients
						var button_name =["gelas_astor","botol2","botol1","piring_roti2","piring_roti1", "piring_roti3","piring_kentang","topping1","topping2"];
						var children_ing = [3,0,0,2,2, 2,4,5,5];
						var isi_ing = [7,2,1,6,4, 5,8,9,10];
						for (var i=0;i<button_name.length;i++){
							if(button.name == button_name[i]){
								if (i==7 || i==8){
									if (!this.ingredients.children[2].visible)
										break;
								}
								if (!this.dragSprite.inputEnabled)
	    							this.dragSprite.inputEnabled = true;

								var j = children_ing[i];
								if(!this.ingredients.children[j].visible){
									this.ingredients.children[j].frameName=this.name_ing[isi_ing[i]]+'.png';
									this.ingredients.children[j].scale.setTo(this.scale_ing[isi_ing[i]]);
									this.ingredients.children[j].visible=true;
								}
								if (flag_tutor){
									this.nextAnim();
								}
							}
						}
					}
			}
			}
		}
	},

	updateTime:function(gameTime){
		if(gameTime >= 0){
		  //gameTime--;
		  this.menit = Math.floor(gameTime/3600);
		  this.detik = Math.floor((gameTime%3600)/60);      
		}
		//else
		  //console.log("waktu habis!");

		if(this.detik < 10)
		  this.str_detik = "0"+this.detik;
		else
		  this.str_detik = this.detik;

		if(this.menit < 10)
		  this.str_menit = "0"+this.menit;
		else
		  this.str_menit = this.menit;
		return  this.str_menit+":"+this.str_detik;
	},  


	initBackground : function(){
		var game_bg = this.addSprite(null,game_bg, ratioXY(0), ratioXY(0),"game_bg",0,0);
		var panel_close = this.addSprite(null, panel_close, ratioXY(190), ratioXY(100),"paper",0.5,0.5);
		panel_close.scale.setTo(0.15);
		this.text_close= this.addBitMapText(null, this.text_close, ratioXY( 190 ), ratioXY( 100 ), 'CLOSE', "grobold", 16, 0.5, 0.5);
		this.text_close.alpha=1;
	},

	initForeground : function(){
		var game_meja = this.addSprite(null,game_meja, ratioXY(0), game.world.height,"game_meja",0,1);
		this.group_meja = game.add.group();
		var arrx=[50,700,760,250,190, 410,560,860,900];
		var arry=[400,400,440,410,470, 415,415,400,430];
		var button_name =["gelas_astor","botol2","botol1","piring_roti2","piring_roti1", "piring_roti3","piring_kentang","topping1","topping2"];
		var scaleButton = [1.6,0.6,0.6,1,1, 1,1,1.7,0.95];
		var visible_min = [3,4,4,1,1, 1,3,2,2];//minimal level for ingredient to visible
		var button = null;
		for (var i=0;i<9;i++){
			button = this.addButton(this.group_meja, button, ratioXY(arrx[i]), ratioXY(arry[i]), button_name[i], button_name[i],0.5,0.5);
			button.visible = visible_min[i]<=level? true:false;
			if (button.visible){
				button.scale.setTo(scaleButton[i]);
				button.inputEnabled=true;
				button.idx =i;
				button.events.onInputOver.add(function(btn){ btn.alpha=0.5;},this);
			    button.events.onInputOut.add(function(btn){ btn.alpha=1;},this);
			    button.events.onInputDown.add(function(btn){ btn.alpha=0.5;},this);
			    button.events.onInputUp.add(function(btn){ btn.alpha=1;},this);
			}
		}

	},

	initGame : function(){
		game.camera.flash(0xffffff,500);
		this.initBackground();
		this.initCustomer();
		this.initBalon(0);
		this.initBalon(1);
		this.initBalon(2);
		this.initBalon(3);
		this.initHati();
		this.initForeground();
		this.initIngredients();
		this.initButton();
		this.initPause();
		this.initResult();
		this.initEnding();
		this.initTutor();
		if (!flag_tutor){
			this.filter_bg = game.add.sprite(ratioXY(0), ratioXY(0),"filter");
			this.filter_bg.inputEnabled=true;
		}

		this.initSound();
	},

	initSound : function(){
		var soundbtn = this.addButton(null,soundbtn , ratioXY(910), ratioXY(50),"soundbtn","sound_on",0.5,0.5);
		soundbtn.scale.setTo(0.5);
		global_sound_change(soundbtn);
	},

	initButton : function(){
		this.group_button = game.add.group();
		var pausebtn = this.addButton(this.group_button,pausebtn, ratioXY(50), ratioXY(590),"pausebtn","pause",0.5,0.5);
		this.trashbtn = this.addSprite(null,this.trashbtn, ratioXY(140), ratioXY(590),"jam",0.5,0.5);
		this.trashbtn.alpha=0;

	    var panel_level = this.addSprite(this.group_button,panel_level,ratioXY(400),ratioXY(590),"score",0.5,0.5);
	    panel_level.width=ratioXY(280);
	    var panel_score = this.addSprite(this.group_button,panel_score,ratioXY(680),ratioXY(590),"score",0.5,0.5);
	    var panel_jam = this.addSprite(this.group_button,panel_jam,ratioXY(890),ratioXY(570),"jam",0.5,0.5);
	    panel_jam.scale.setTo(1.2);

		var text_score1= this.addBitMapText(this.group_button, text_score1, ratioXY( 580 ), ratioXY( 587 ), '$', "grobold", 25, 0, 0.5);
		this.text_score= this.addBitMapText(this.group_button, this.text_score, ratioXY( 780 ), ratioXY( 587 ), '', "grobold", 25, 1, 0.5);
		this.text_score.text =  this.curScore+'/'+ this.maxScore[level-1];
		this.animCoin = this.addBitMapText(this.group_button, this.animCoin, ratioXY( 725 ), ratioXY( 587 ), '+'+this.incScore, "grobold", 25, 1, 0.5);
		this.animCoin.alpha=0;

		this.text_jam= this.addBitMapText(this.group_button, this.text_jam, ratioXY( 890 ), ratioXY( 570 ), '', "grobold", 30, 0.5, 0.5);
		this.text_jam.text = this.updateTime(this.game_time);

		for (var i=0;i<maxlevel;i++){
			if (i<level)
	    		var star = this.addSprite(this.group_button,star,ratioXY(295+i*30),ratioXY(590),"star_on",0.5,0.5);
	    	else
	    		var star = this.addSprite(this.group_button,star,ratioXY(295+i*30),ratioXY(590),"star_off",0.5,0.5);
	    	star.scale.setTo(0.33);
		}
	},

	onDragStart: function(sprite, pointer){
		this.flag_drag=true;
	},

	clearPiring: function(){
		this.ingredients.forEachAlive(function(ing){
			if (ing.tipe!=3 && ing.visible){
				ing.visible=false;
			}
		},this);
		if (this.dragSprite.inputEnabled)
			this.dragSprite.inputEnabled=false;
	},

	onDragStop: function(sprite, pointer){
		if (this.checkOverlap(sprite,this.trashbtn)){
			this.clearPiring();
			callAudio(sfx_trash,false,1);
			if (flag_tutor){
				this.nextAnim();
			}
		}
		var fail=false;
		this.customers.forEachAlive(function(cust){
			if (!fail && cust.visible && this.checkOverlap(this.spotOverlap,cust)){
				for (var i=0;i<6;i++){
					if (this["balons"+cust.idx].children[i+1].visible==this["ingredients"].children[i].visible){
						if (this["ingredients"].children[i].visible){
							if(this["balons"+cust.idx].children[i+1].frameName==this["ingredients"].children[i].frameName){
								//console.log(this["balons"+cust.idx].children[i+1].frameName+"=="+this["ingredients"].children[i].frameName);
							}else{
								fail=true;
								//console.log(this["balons"+cust.idx].children[i+1].frameName+"=="+this["ingredients"].children[i].frameName);
							}
						}
					}else{
						fail=true;
						//console.log(this["balons"+cust.idx].children[i+1].visible+"=="+this["ingredients"].children[i].visible);
					}
				}
				if (fail){
					//console.log("fail");
					callAudio(sfx_kabur,false,1);
				}else{
					//console.log("success");
					if (flag_tutor){
						this.nextAnim();
					}
					this.clearPiring();


					cust.request--;
					if (cust.request>0){
						cust.cd_balon=cust.maxcd_balon;
						this["balons"+cust.idx].visible=false;
						callAudio(sfx_benar,false,1);
					}else{
						callAudio(sfx_cash,false,1);
						//cust run
						this.customerServed++;
						this.bonus+=this.bonusInc*level;
						this["balons"+cust.idx].visible=false;
						game.time.events.add(Phaser.Timer.SECOND *1, function (){  							
							cust.visible=false;
							this.hatis.forEachAlive(function(hati){
								if (hati.idx==cust.idx){
									hati.visible=false;
								}
							},this);
						},this);
					}
					this.animCoin.alpha=0;
					this.animCoin.text ='+ '+ (this.incScore+cust.hati+this.bonusInc);
					this.addTween(this.animCoin,1,1,this.animCoin.x+ratioXY(0),this.animCoin.y+ratioXY(-50),1500,Phaser.Easing.Quadratic.Out,0);

					this.curScore+=this.incScore+cust.hati;
					this.text_score.text =  (this.curScore+this.bonus) +'/'+ this.maxScore[level-1];
					cust.hati=cust.hati+2<=5?cust.hati+2:5;
					cust.animations.play(0);
					this.hatis.forEachAlive(function(hati){
						if (hati.idx==cust.idx){
							hati.animations.play(cust.hati-1);
						}
					},this);

					fail=true;//break
				}
			}
		},this);
		this.flag_drag=false;
	    this.dragSprite.x = this.dragSprite.curx;
	    this.dragSprite.y = this.dragSprite.cury;
		this.updatePosIngredients();
	},

	initIngredients: function(){
		this.ingredients = game.add.group();
	    this.ingredients.createMultiple(6, "sprites_game");
	    this.ingredients.setAll('anchor.x', 0.5);
	    this.ingredients.setAll('anchor.y', 0.5);
		this.ingredients.visible = true;

		this.spawnIngredients(0,585,425,1,0);//gelas
		this.spawnIngredients(0,500,495,3,1);//piring
		this.spawnIngredients(0,500,480,6,0);//roti
		this.spawnIngredients(0,540,510,7,0);//astor
		this.spawnIngredients(0,460,510,8,0);//kentang
		this.spawnIngredients(0,500,475,10,0);//topping

	    this.dragSprite = game.add.sprite(ratioXY(500),ratioXY(495),'sprites_game');
	    this.dragSprite.frameName = 'piring.png';
	    this.dragSprite.alpha=0;
	    this.dragSprite.anchor.setTo(0.5);
	    this.dragSprite.curx = this.dragSprite.x;
	    this.dragSprite.cury = this.dragSprite.y;
	    this.dragSprite.width = this.ingredients.width;
	    this.dragSprite.height = this.ingredients.height;
	    
	    this.dragSprite.inputEnabled = true;
	    this.dragSprite.input.enableDrag();
	    this.dragSprite.events.onDragStart.add(this.onDragStart, this);
	    this.dragSprite.events.onDragStop.add(this.onDragStop, this);
	    this.dragSprite.inputEnabled = false;

	    this.spotOverlap = game.add.sprite(ratioXY(500),ratioXY(495),'sprites_game');
	    this.spotOverlap.frameName = 'pause.png';
	    this.spotOverlap.anchor.setTo(0.5);
	    this.spotOverlap.alpha=0;

	},

	spawnIngredients: function(idx, x, y, tipe, isVisible){ 
		var ing = this.ingredients.getFirstDead();
		if (ing){
			//this.name_ing = ['balon','gelas1','gelas2','piring','roti1','roti2','roti3','astor','kentang','roti_topping1','roti_topping2'];
	        ing.reset(ratioXY(x),ratioXY(y));
    		ing.frameName = this.name_ing[tipe]+'.png';
    		ing.scale.setTo(this.scale_ing[tipe]);
	        ing.idx = idx; 
	        ing.tipe = tipe;
	        ing.visible=isVisible==1? true:false;
	    }
	},

	initCustomer: function(){
		this.customers = game.add.group();
	    this.customers.createMultiple(4, "sprites_game");
	    this.customers.setAll('anchor.x', 0.5);
	    this.customers.setAll('anchor.y', 1);
		this.customers.visible = true;
		this.spawnCustomer(0,120,400,0,0);
		this.spawnCustomer(1,360,400,1,0);
		this.spawnCustomer(2,600,400,2,0);
		this.spawnCustomer(3,840,400,3,0);
	},

	spawnCustomer: function(idx, x, y, tipe, isVisible){ 
		var cust = this.customers.getFirstDead();
		if (cust){
	        cust.reset(ratioXY(x),ratioXY(y));
	        cust.loadTexture(this.name_cust[tipe]);
	        cust.animations.add(0,[0],5,false);
	        cust.animations.add(1,[1],5,false);
	        cust.animations.add(2,[2,3],15,true);
	        cust.animations.play(0);
	        cust.idx = idx; 
	        cust.tipe = tipe;
	        cust.hati = 5;
	        cust.maxcd_hati = this.cd_hati[0];
	        cust.cd_hati = cust.maxcd_hati;
	        cust.maxcd_balon = this.cd_balon[level-1];
	        cust.cd_balon = cust.maxcd_balon;
	        cust.request = game.rnd.integerInRange(this.minRequest[level-1],this.maxRequest[level-1]);
	        cust.visible=isVisible==1? true:false;
	    }
	},

	initHati: function(){
		this.hatis = game.add.group();
	    this.hatis.createMultiple(4, "hati");
	    this.hatis.setAll('anchor.x', 0.5);
	    this.hatis.setAll('anchor.y', 0.5);
		this.hatis.visible = true;
		this.spawnHatis(0,120,300,4,0);
		this.spawnHatis(1,360,300,4,0);
		this.spawnHatis(2,600,300,4,0);
		this.spawnHatis(3,840,300,4,0);
	},

	spawnHatis: function(idx, x, y, tipe, isVisible){ 
		var hati = this.hatis.getFirstDead();
		if (hati){
	        hati.reset(ratioXY(x),ratioXY(y));
	        hati.animations.add(0,[0],5,false);
	        hati.animations.add(1,[1],5,false);
	        hati.animations.add(2,[2],10,true);
	        hati.animations.add(3,[3],10,true);
	        hati.animations.add(4,[4],10,true);
	        hati.animations.play(tipe);
	        hati.idx = idx; 
	        hati.visible=isVisible==1? true:false;
	    }
	},

	initBalon: function(idx){
		this['balons'+idx] = game.add.group();
	    this['balons'+idx].createMultiple(7, "sprites_game");
	    this['balons'+idx].setAll('anchor.x', 0.5);
	    this['balons'+idx].setAll('anchor.y', 0.5);

		this.spawnbalons(idx,520,460,0,1);//balon
		this.spawnbalons(idx,585,425,1,1);//gelas
		this.spawnbalons(idx,500,495,3,1);//piring
		this.spawnbalons(idx,500,480,6,1);//roti
		this.spawnbalons(idx,540,510,7,1);//astor
		this.spawnbalons(idx,460,510,8,1);//kentang
		this.spawnbalons(idx,500,475,10,1);//topping

		this['balons'+idx].scale.setTo(0.5);
		var deltax=[-180,50,300,535];
		var deltay=[-160,-160,-160,-160];
		this['balons'+idx].x +=ratioXY(deltax[idx]);
		this['balons'+idx].y +=ratioXY(deltay[idx]);
		
		this['balons'+idx].visible = false;
	},

	spawnbalons: function(idx, x, y, tipe, isVisible){ 
		var balon = this['balons'+idx].getFirstDead();
		if (balon){
	        balon.reset(ratioXY(x),ratioXY(y));
    		balon.frameName = this.name_ing[tipe]+'.png';
    		balon.scale.setTo(this.scale_ing[tipe]);
	        balon.idx = idx; 
	        balon.tipe = tipe;
	        balon.visible=isVisible==1? true:false;
	    }
	},

	pickObject: function(pickOpt, group, sprite, x, y, name, nameImage, anchorx, anchory){
		if (pickOpt==0)
			return this.addSprite(group, sprite, x, y, nameImage, anchorx, anchory);
		else
		if (pickOpt==1)
			return this.addButton(group, sprite, x, y, name, nameImage, anchorx, anchory,1);
		else
			return this.addBitMapText(group, sprite, x, y, nameImage, "blue_font", 20, 0.5, 0.5);
	},

	setxyObject: function(obj, x, y){
		obj.x = x;
		obj.y = y;
		obj.alpha = 1;
		return obj;
	},

//////////start tutor	
	initTutor: function(){
		this.group_tutor= game.add.group();
		var bg = game.add.button(ratioXY(0),ratioXY(0),"filter",this.buttonPress, this);
		bg.name='tutorbtn';
		this.group_tutor.add(bg);

		var arrx = [780,700];
		var arry = [490,270];
		var pickOpt = [0,0];
		var name = ["", ""];
		var nameImage =  ["char", "balon"];
		var scale = [0.5,2];
		for (var i=0;i<2;i++){
			var obj = this.pickObject(pickOpt[i], this.group_tutor, obj, ratioXY(arrx[i]),ratioXY(arry[i]), name[i], nameImage[i], 0.5,0.5);
			obj.scale.setTo(scale[i]);
		}
		this.text_tutor = this.addBitMapText(this.group_tutor, this.text_tutor , ratioXY( 700 ), ratioXY( 270 ), 'Click the bread to put it on the plate', "grobold", 20, 0.5, 0.5);
		this.text_tutor.maxWidth=ratioXY(200);
		this.text_tutor.align='center';
		var text= this.addBitMapText(this.group_tutor, text, ratioXY( 480 ), ratioXY( 550 ), 'tap to continue', "putih_font", 30, 0.5, 0.5);
		
		var FOG = game.add.button(game.world.width-100,15,"logo2",this.buttonPress,this,0,0,0);
		FOG.anchor.setTo(1,0);
		FOG.name = "FOG";
		this.group_tutor.add(FOG);		
		
		if (flag_tutor){
			this.group_tutor.visible=true;
			this.tweenTutor(1);
			this.group_button.visible=false;//pausebtn
		}else
			this.group_tutor.visible=false;
			//this.tweenTutor(1);
	},

	reinitTutor: function(){
		var arrx = [0,780,700,700,480];
		var arry = [0,490,270,270,550];
		for (var i=0; i<5; i++)
			this.setxyObject(this.group_tutor.children[i],ratioXY(arrx[i]),ratioXY(arry[i]));
	},

	tweenTutor: function(direction){
		var duration= 1000;
		var max_duration = direction==0?  1000:0;
		this.flag_tween=true;
		if (direction==1){
			this.group_tutor.visible=true;
		    this.texts = this.resetText(false);
			this.reinitTutor();
		}
		this.group_tutor.children[4].alpha=0;
		var deltax = [100,0,0,0];
		var deltay = [0,0,0,0];
		var delay = [0,1000,1000,1000];
		for (var i=1;i<5;i++){
			this.addTween(this.group_tutor.children[i], direction, 0, this.group_tutor.children[i].x+ratioXY(deltax[i-1]), this.group_tutor.children[i].y+ratioXY(deltay[i-1]), duration, Phaser.Easing.Quadratic.Out, Math.abs(max_duration-delay[i-1]));
		}		
		if (direction==1){
			var twn =this.addTween(this.group_tutor.children[0], direction, 1, this.group_tutor.children[0].x+ratioXY(0), this.group_tutor.children[0].y+ratioXY(0), duration, Phaser.Easing.Quadratic.Out, Math.abs(max_duration-duration) );
		}else{
			var twn =this.addTween(this.group_tutor.children[0], direction, 0, this.group_tutor.children[0].x+ratioXY(0), this.group_tutor.children[0].y+ratioXY(0), duration, Phaser.Easing.Quadratic.Out, Math.abs(max_duration-0) );
		}
		twn.onComplete.addOnce(function(){
			if (!this.group_tutor.children[4].tweenName)
				this.group_tutor.children[4].tweenName = game.add.tween(this.group_tutor.children[4].scale).to({x:1.4,y:1.4}, 1000, 'Linear', true, 0, -1, true);
			this.flag_tween=false;
			if (direction==0){
				this.group_tutor.visible=false;
				if (this.timeline==13){
					this.group_meja.children[3].inputEnabled=false;
					this.group_meja.children[4].inputEnabled=false;
					this.group_meja.children[5].tweenName = game.add.tween(this.group_meja.children[5]).to({alpha:0.1}, 1000, 'Linear', true, 0, -1, true);
				}else
				if (this.timeline==11){
					this.ingredients.children[2].visible=true;
					this.ingredients.tweenName = game.add.tween(this.ingredients).to({alpha:0.1}, 1000, 'Linear', true, 0, -1, true);
					this.trashbtn.alpha=0.6;
					this.trashbtn.tweenName = game.add.tween(this.trashbtn.scale).to({x:1.4,y:1.4}, 1000, 'Linear', true, 0, -1, true);
					if (!this.dragSprite.inputEnabled)
						this.dragSprite.inputEnabled = true;
				}else
				if (this.timeline==9){
					this.group_meja.children[5].inputEnabled=false;
					this.group_meja.children[4].inputEnabled=false;
					this.group_meja.children[3].inputEnabled=true;
					this.group_meja.children[3].tweenName = game.add.tween(this.group_meja.children[3]).to({alpha:0.1}, 1000, 'Linear', true, 0, -1, true);
				}else
				if (this.timeline==7){
					this.ingredients.tweenName = game.add.tween(this.ingredients).to({alpha:0.1}, 1000, 'Linear', true, 0, -1, true);
				}
			}else{
				if (this.timeline==16){
					this.nextAnim();
				}else
				if (this.timeline==12){
					this.nextLine();
				}else
				if (this.timeline==10){
					this.nextLine();
				}else
				if (this.timeline==8){
					this.nextLine();
				}else
				if (this.timeline==6){
					this.nextLine();
				}
			}
		},this);
	},

	nextLine:function(){
	    if (this.lineIndex === this["arr_tutor"].length){
	        game.time.events.add(this.lineDelay, this.closeDialog, this);
	        return;
	    }	    
	    this.group_tutor.children[4].alpha=0;
		this.isTalk = true;
		for(var i=0;i<this["arr_tutor"][this.lineIndex].length;i++)
			this.line.push(this["arr_tutor"][this.lineIndex][i]);
	    this.wordIndex = 0;
	    this.timeEvents.push(game.time.events.repeat(this.wordDelay, this.line.length, this.nextWord, this));
		this.texts ="";
	    this.lineIndex++;
	},

	nextWord:function(){
	    this.texts = this.texts.concat(this.line[this.wordIndex]);
	    this.wordIndex++;
	    if (this.wordIndex === this.line.length){
	        this.isTalk = false;
	        this.group_tutor.children[4].alpha=1;
	    }
	},

	resetText: function(newLine){
		this.line = [];
		this.wordIndex = 0;
		if (newLine)
			this.lineIndex = 0;
		return "";
	},

	nextAnim: function(){
		if (this.lineIndex < this["arr_tutor"].length){
			this.newDialog();
		}else{
			console.log("dialog habis");
			flag_tutor=false;
			level=curlevel;
			game.state.start('game');
		}
	},

	newDialog: function(){
		if (!this.isTalk){
		    this.text_tutor.text = this.resetText(false);
			this.animDialog();
		}else{//skip running text
			//clear all time event 
			for (var i=0; i<this.timeEvents.length; i++){
				if(this.timeEvents[i])
					game.time.events.remove(this.timeEvents[i]); 
			}
			this.texts = this["arr_tutor"][this.lineIndex-1];
      	  	this.text_tutor.text = this.texts;
			this.isTalk=false;
		}
	},

	animDialog: function(){
		if (this.timeline==16){
			this.nextLine();
		}else
		if (this.timeline==15){
			//spawn customer + balon
			this.cd_spawn[level-1]=1;
			this.checkSpawnCustomer();
			this.customers.forEachAlive(function(cust){
				cust.cd_balon=1;
			},this);
			this.checkRequestCustomer();
			this.nextLine();
		}else
		if (this.timeline==14){
			this.tweenTutor(0);
		}else
		if (this.timeline==13){
			this.group_meja.children[5].inputEnabled=false;
			this.group_meja.children[5].tweenName.stop();
			this.group_meja.children[5].alpha=1;
			game.time.events.add(Phaser.Timer.SECOND * 0.5, function (){  
				this.tweenTutor(1);
			},this);
		}else
		if (this.timeline==12){
			this.tweenTutor(0);
		}else
		if (this.timeline==11){
			this.ingredients.tweenName.stop();
			this.ingredients.alpha =1;
			this.trashbtn.tweenName.stop();
			this.trashbtn.y+=320;
			this.tweenTutor(1);
		}else
		if (this.timeline==10){
			this.tweenTutor(0);
		}else
		if (this.timeline==9){
			this.group_meja.children[3].inputEnabled=false;
			this.group_meja.children[3].tweenName.stop();
			this.group_meja.children[3].alpha=1;
			game.time.events.add(Phaser.Timer.SECOND * 0.5, function (){  
				this.tweenTutor(1);
			},this);
		}else
		if (this.timeline==8){
			this.tweenTutor(0);
		}else
		if (this.timeline==7){
			this.ingredients.tweenName.stop();
			this.ingredients.alpha =1;
			game.time.events.add(Phaser.Timer.SECOND * 0.5, function (){  
				this.tweenTutor(1);
			},this);
		}else
		if (this.timeline==6){
		}
		//cek replay animasi
		if (this.timeline>=6){
			this.timeline--;
		}else{
			//out
		}
	},
//////////end tutor	

	initPause: function(){
		this.group_pause= game.add.group();
		var bg = game.add.sprite(ratioXY(0),ratioXY(0),"filter");
		bg.inputEnabled=true;
		this.group_pause.add(bg);

		var arrx = [480,480, 380,580];
		var arry = [320,270, 400,400];
		var pickOpt = [0,1,1,1];
		var name = ["", "resumebtn","menubtn","morebtn"];
		var nameImage =  ["paper", "play","home","moregames"];
		for (var i=0;i<4;i++){
			var obj = this.pickObject(pickOpt[i], this.group_pause, obj, ratioXY(arrx[i]),ratioXY(arry[i]), name[i], nameImage[i], 0.5,0.5);
			if(i==0)
				obj.scale.setTo(0.8);
			if(i==2 || i==3)
				obj.scale.setTo(0.7);
		}
		var text= this.addBitMapText(this.group_pause, text, ratioXY( 480 ), ratioXY( 90 ), 'Pause', "grobold", 35, 0.5, 0.5);
		
		var FOG = game.add.button(game.world.centerX,game.world.centerY+170,"logo2",this.buttonPress,this,0,0,0);
		FOG.anchor.setTo(0.5);
		FOG.name = "FOG";
		this.group_pause.add(FOG);
		
		this.group_pause.visible=false;
		//this.tweenPause(1);
	},

	reinitPause: function(){
		var arrx = [480,480, 380,580];
		var arry = [320,270, 400,400];
		for (var i=0; i<4; i++)
			this.setxyObject(this.group_pause.children[i+1],ratioXY(arrx[i]),ratioXY(arry[i]));
	},

	tweenPause: function(direction){
		var duration= 1000;
		var max_duration = direction==0?  1000:0;
		this.flag_tween=true;
		if (direction==1){
			this.reinitPause();
		}
		var deltax = [0,0,10, -10,0];
		var deltay = [-100,-10,-10, -10,-10];
		var delay = [0,500, 750,1000, 1000];
		for (var i=1;i<6;i++){
			this.addTween(this.group_pause.children[i], direction, 0, this.group_pause.children[i].x+ratioXY(deltax[i-1]), this.group_pause.children[i].y+ratioXY(deltay[i-1]), duration, Phaser.Easing.Quadratic.Out, Math.abs(max_duration-delay[i-1]));
		}		
		if (direction==1){
			var twn =this.addTween(this.group_pause.children[0], direction, 1, this.group_pause.children[0].x+ratioXY(0), this.group_pause.children[0].y+ratioXY(0), duration, Phaser.Easing.Quadratic.Out, Math.abs(max_duration-duration) );
		}else{
			var twn =this.addTween(this.group_pause.children[0], direction, 0, this.group_pause.children[0].x+ratioXY(0), this.group_pause.children[0].y+ratioXY(0), duration, Phaser.Easing.Quadratic.Out, Math.abs(max_duration-0) );
		}
		twn.onComplete.addOnce(function(){
			this.flag_tween=false;
			if (direction==0){
				this.group_pause.visible=false;
			}
		},this);
	},

	initEnding: function(){
		this.group_ending= game.add.group();
		var bg = game.add.sprite(ratioXY(0),ratioXY(0),"filter");
		bg.inputEnabled=true;
		this.group_ending.add(bg);

		var arrx = [480,460,360,480,600];
		var arry = [320,160,590,590,590];
		var pickOpt = [0,0,1,1,1];
		var name = ["","", "morebtn","replaybtn","menubtn"];
		var nameImage =  ["paper","icon_win","moregames","reset","menu"];
		var scale = [0.95,0.46,0.5,0.5,0.5];
		for (var i=0;i<5;i++){
			var obj = this.pickObject(pickOpt[i], this.group_ending, obj, ratioXY(arrx[i]),ratioXY(arry[i]), name[i], nameImage[i], 0.5,0.5);
			obj.scale.setTo(scale[i]);
		}
		var title = this.addBitMapText(this.group_ending, title, ratioXY( 480 ), ratioXY( 50 ), 'Congratulations', "grobold", 24, 0.5,0.5);

		var text1 = this.addBitMapText(this.group_ending, text1, ratioXY( 300 ), ratioXY( 260 ), 'Total Profit', "grobold", 30, 0,0.5);

		var text2 = this.addBitMapText(this.group_ending, text2, ratioXY( 300 ), ratioXY( 300 ), 'Customer Served', "grobold", 20, 0,0.5);
		var text3 = this.addBitMapText(this.group_ending, text3, ratioXY( 300 ), ratioXY( 360 ), 'Total Sales ', "grobold", 20, 0,0.5);
		var text4 = this.addBitMapText(this.group_ending, text4, ratioXY( 300 ), ratioXY( 390 ), 'Total Bonus ', "grobold", 20, 0,0.5);
		var text5 = this.addBitMapText(this.group_ending, text5, ratioXY( 300 ), ratioXY( 420 ), 'Grand Total', "grobold", 20, 0,0.5);
		
		this.ending1 = this.addBitMapText(this.group_ending, this.ending1 , ratioXY( 650 ), ratioXY( 300 ), '0', "grobold", 20, 1,0.5);
		this.ending2 = this.addBitMapText(this.group_ending, this.ending2 , ratioXY( 650 ), ratioXY( 360 ), '0', "grobold", 20, 1,0.5);
		this.ending3 = this.addBitMapText(this.group_ending, this.ending3 , ratioXY( 650 ), ratioXY( 390 ), '0', "grobold", 20, 1,0.5);
		this.ending4 = this.addBitMapText(this.group_ending, this.ending4 , ratioXY( 650 ), ratioXY( 420 ), '0', "grobold", 20, 1,0.5);
		
		var FOG = game.add.button(game.world.centerX,game.world.centerY+170,"logo2",this.buttonPress,this,0,0,0);
		FOG.anchor.setTo(0.5);
		FOG.name = "FOG";
		this.group_ending.add(FOG);
		
		this.group_ending.visible=false;
		//this.tweenEnding(1);
	},

	tweenEnding: function(direction){
		var duration= 1000;
		var max_duration = direction==0?  3250:0;
		this.flag_tween=true;
		this.ending1.text = customerServed;
		this.ending2.text = totalcoin;
		this.ending3.text = totalBonus;
		this.ending4.text = (totalcoin+totalBonus);

		var deltax = [0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0];
		var deltay = [-100,0,100,100,100, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0];
		var delay = [0,1000,2750,3000,3250, 1000,1250,1500,1750,2000, 2250,2500,2750,1500,1750, 2000,2250,2500,2750];
		for (var i=1;i<16;i++){
			this.addTween(this.group_ending.children[i], direction, 0, this.group_ending.children[i].x+ratioXY(deltax[i-1]), this.group_ending.children[i].y+ratioXY(deltay[i-1]), duration, Phaser.Easing.Quadratic.Out, Math.abs(max_duration-delay[i-1]));
		}		
		var twn =this.addTween(this.group_ending.children[0], direction, 1, this.group_ending.children[0].x+ratioXY(0), this.group_ending.children[0].y+ratioXY(0), duration, Phaser.Easing.Quadratic.Out, Math.abs(max_duration-3250) );
		twn.onComplete.addOnce(function(){
			callAudio(sfx_win,false,1);
			this.flag_tween=false;
		},this);
	},

	initResult: function(){
		this.group_result= game.add.group();
		var bg = game.add.sprite(ratioXY(0),ratioXY(0),"filter");
		bg.inputEnabled=true;
		this.group_result.add(bg);

		var arrx = [480,480,360,480,600];
		var arry = [320,160,590,590,590];
		var pickOpt = [0,0,1,1,1];
		var name = ["","", "morebtn","retrybtn","nextbtn"];
		var nameImage =  ["paper","icon_win","moregames","reset","play"];
		var scale = [0.95,0.46,0.5,0.5,0.5];
		for (var i=0;i<5;i++){
			var obj = this.pickObject(pickOpt[i], this.group_result, obj, ratioXY(arrx[i]),ratioXY(arry[i]), name[i], nameImage[i], 0.5,0.5);
			obj.scale.setTo(scale[i]);
		}
		var title = this.addBitMapText(this.group_result, title, ratioXY( 480 ), ratioXY( 50 ), 'Result', "grobold", 40, 0.5,0.5);

		var text1 = this.addBitMapText(this.group_result, text1, ratioXY( 300 ), ratioXY( 260 ), 'Daily Report', "grobold", 30, 0,0.5);

		var text2 = this.addBitMapText(this.group_result, text2, ratioXY( 300 ), ratioXY( 300 ), 'Total Customer', "grobold", 20, 0,0.5);
		var text3 = this.addBitMapText(this.group_result, text3, ratioXY( 300 ), ratioXY( 330 ), 'Customer Served', "grobold", 20, 0,0.5);
		var text4 = this.addBitMapText(this.group_result, text4, ratioXY( 300 ), ratioXY( 375 ), 'Sales Target ', "grobold", 20, 0,0.5);
		var text5 = this.addBitMapText(this.group_result, text5, ratioXY( 300 ), ratioXY( 420 ), 'Total Sales ', "grobold", 20, 0,0.5);
		var text6 = this.addBitMapText(this.group_result, text6, ratioXY( 300 ), ratioXY( 450 ), 'Bonus ', "grobold", 20, 0,0.5);
		var text7 = this.addBitMapText(this.group_result, text7, ratioXY( 300 ), ratioXY( 480 ), 'Total ', "grobold", 20, 0,0.5);
		
		this.result1 = this.addBitMapText(this.group_result, this.result1 , ratioXY( 650 ), ratioXY( 300 ), '0', "grobold", 20, 1,0.5);
		this.result2 = this.addBitMapText(this.group_result, this.result2 , ratioXY( 650 ), ratioXY( 330 ), '0', "grobold", 20, 1,0.5);
		this.result3 = this.addBitMapText(this.group_result, this.result3 , ratioXY( 650 ), ratioXY( 375 ), '0', "grobold", 20, 1,0.5);
		this.result4 = this.addBitMapText(this.group_result, this.result4 , ratioXY( 650 ), ratioXY( 420 ), '0', "grobold", 20, 1,0.5);
		this.result5 = this.addBitMapText(this.group_result, this.result5 , ratioXY( 650 ), ratioXY( 450 ), '0', "grobold", 20, 1,0.5);
		this.result6 = this.addBitMapText(this.group_result, this.result6 , ratioXY( 650 ), ratioXY( 480 ), '0', "grobold", 20, 1,0.5);
		
		var FOG = game.add.button(0,game.world.height-20,"logo2",this.buttonPress,this,0,0,0);
		FOG.anchor.setTo(0,1);
		FOG.name = "FOG";
		this.group_result.add(FOG);
		
		this.group_result.visible=false;
		//this.tweenResult(1);
	},

	tweenResult: function(direction){
		var duration= 1000;
		var max_duration = direction==0?  3250:0;
		this.flag_tween=true;
		this.result1.text = this.totalCustomer;
		this.result2.text = this.customerServed;
		this.result3.text = this.maxScore[level-1];
		this.result4.text = this.curScore;
		this.result5.text = this.bonus;
		this.result6.text = (this.curScore+this.bonus);
		saveLoadData(1);
		if ((this.curScore+this.bonus)<this.maxScore[level-1]){
			callAudio(sfx_gameover,false,1);
			this.group_result.children[2].frameName = 'icon_lose.png';
			this.group_result.children[5].visible = false;
		}else{
			callAudio(sfx_win,false,1);
			this.group_result.children[2].frameName = 'icon_win.png';
			this.group_result.children[5].visible = true;
			customerServed+=this.customerServed;
			totalcoin+=this.curScore;
			totalBonus+=this.bonus;
		}

		var deltax = [0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0];
		var deltay = [-100,0,100,100,100, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0];
		var delay = [0,1000,2750,3000,3250, 1000,1250,1500,1750,2000, 2250,2500,2750,1500,1750, 2000,2250,2500,2750];
		for (var i=1;i<20;i++){
			this.addTween(this.group_result.children[i], direction, 0, this.group_result.children[i].x+ratioXY(deltax[i-1]), this.group_result.children[i].y+ratioXY(deltay[i-1]), duration, Phaser.Easing.Quadratic.Out, Math.abs(max_duration-delay[i-1]));
		}		
		var twn =this.addTween(this.group_result.children[0], direction, 1, this.group_result.children[0].x+ratioXY(0), this.group_result.children[0].y+ratioXY(0), duration, Phaser.Easing.Quadratic.Out, Math.abs(max_duration-3250) );
		twn.onComplete.addOnce(function(){
			this.flag_tween=false;
		},this);
	},

	checkOverlap: function(spriteA, spriteB) {//tabrakan coin/obs
	    var boundsA = spriteA.getBounds();
	    var boundsB = spriteB.getBounds();
	    return Phaser.Rectangle.intersects(boundsA, boundsB);
	},

	popupBalon: function(idx){
		callAudio(sfx_ambil,false,1);
		var children =[1,3,4,5,6];//children balon ke -> 1-gelas, 3-roti, 4-astor, 5-kentang, 6-topping ->lihat spawnBalon
		var minisi =[1,4,7,8,9];//isi children ->lihat array this.name_ing
		var maxisi =[2,6,7,8,10];
		var adaisi =[0,1,0,0,0];//bisa kosong kecuali roti
		var visible_min = [4,1,3,3,2];
		//level >5 min 2 ingredient, >3 min 1 ingredient selain roti
		var arrIng = [0,2,3,4];//roti exclude karna harus selalu ada/visible Not null
		var notNull1=-1;
		var notNull2=-1;
		if (level>5){
			notNull1 = game.rnd.pick(arrIng);
			notNull2 =game.rnd.pick(arrIng);
		}else
		if (level>=3){
			notNull1 = game.rnd.pick(arrIng);
		}else{
		}

		var ran=0;
		for (var i=0;i<5;i++){
			ran =  game.rnd.integerInRange(minisi[i],maxisi[i]);
			if (flag_tutor){
				ran=6;
			}
			this["balons"+idx].children[children[i]].frameName=this.name_ing [ran]+'.png';
			this["balons"+idx].children[children[i]].scale.setTo(this.scale_ing[ran]);
			if (adaisi[i]==0){
				if (i==notNull1){
					this["balons"+idx].children[children[i]].visible= true;	
				}else
				if (i==notNull2){
					this["balons"+idx].children[children[i]].visible= true;
				}else
					this["balons"+idx].children[children[i]].visible = game.rnd.pick([true,false]);
			}
			if (visible_min[i]>level){
				this["balons"+idx].children[children[i]].visible =false;
			}
		}

		this["balons"+idx].visible=true;
	},

	checkSpawnCustomer: function(){
		if (this.cd_spawn[level-1]>0){
			this.cd_spawn[level-1]--;
			if (this.cd_spawn[level-1]<=0){
				this.cd_spawn[level-1] = this.maxcd_spawn[level-1];
				var ran = game.rnd.integerInRange(0,3);
				this.customers.forEachAlive(function(cust){
					if (!cust.visible && ran==cust.idx){
						//init cust
						this.totalCustomer++;
						callAudio(sfx_come,false,1);
						cust.tipe=game.rnd.pick(this.tipeCust[level-1]);
						cust.loadTexture (this.name_cust[cust.tipe]);
				        cust.animations.play(0);
						cust.maxcd_hati=this.maxcd_hati[cust.tipe];
				        cust.cd_hati = cust.maxcd_hati;

						cust.animations.play(0);
						cust.hati=5;
						cust.cd_balon=cust.maxcd_balon;
	       			 	cust.request = game.rnd.integerInRange(this.minRequest[level-1],this.maxRequest[level-1]);
						cust.visible=true;
						this.hatis.forEachAlive(function(hati){
							if (hati.idx==cust.idx){
								hati.visible=true;
								hati.animations.play(cust.hati-1);
							}
						},this);
					}
				},this);
			}
		}
	
	},

	checkRequestCustomer: function(){
		this.customers.forEachAlive(function(cust){
		if (cust.visible){
			if (cust.cd_hati>0){
				cust.cd_hati--;
				if (cust.cd_hati<=0){
					cust.cd_hati=cust.maxcd_hati;
					if(cust.hati>0){
						cust.hati--;
						if(cust.hati<=0){
							//cust run
							callAudio(sfx_kabur,false,1);
							cust.visible=false;
							this["balons"+cust.idx].visible=false;
							this.hatis.forEachAlive(function(hati){
								if (hati.idx==cust.idx){
									hati.visible=false;
								}
							},this);
						}else{
							if (cust.hati<3)
								cust.animations.play(2);
							else
							if (cust.hati<4)
								cust.animations.play(1);
							this.hatis.forEachAlive(function(hati){
								if (hati.idx==cust.idx){
									hati.animations.play(cust.hati-1);
								}
							},this);
						}
					}
				}
			}
			if (cust.cd_balon>0){
				cust.cd_balon--;
				if (cust.cd_balon<=0){
					//popup balon
					this.popupBalon(cust.idx);
				}
			}
		}
		},this);

	},

	updatePosIngredients: function(){
		this.ingredients.x=this.dragSprite.x+ratioXY(-500);
		this.ingredients.y=this.dragSprite.y+ratioXY(-495);
		this.spotOverlap.x=this.dragSprite.x;
		this.spotOverlap.y=this.dragSprite.y;
	},

	update: function(){
	  if (flag_tutor){//tutorial
	 	if(  this.group_tutor.visible ){
	 		if (this.text_tutor.text != this.texts )
      	  		this.text_tutor.text = this.texts;
      	}

		if (this.flag_drag){
			this.updatePosIngredients();
		}
	  }else
	  if(!this.group_result.visible && !this.group_ending.visible){
		if(!this.group_pause.visible){
			if (this.flag_drag){
				this.updatePosIngredients();
			}
			if (this.game_time>0){				
				if (this.text_close.text =='CLOSE'){
					if (this.filter_bg.alpha==1){
						this.filter_bg.alpha-=0.001;
						this.addTween(this.filter_bg,0,0,this.filter_bg.x,this.filter_bg.y,1000,Phaser.Easing.Quadratic.Out,1000);
						var twn = this.addTween(this.text_close,0,0,this.text_close.x+ratioXY(0),this.text_close.y+ratioXY(10),1000,Phaser.Easing.Quadratic.Out,2000);
						twn.onComplete.addOnce(function(){
							this.text_close.y+=ratioXY(-20);
							this.text_close.text ='OPEN';
							this.filter_bg.visible=false;
							var twn2 = this.addTween(this.text_close,0,1,this.text_close.x+ratioXY(0),this.text_close.y+ratioXY(10),1000,Phaser.Easing.Quadratic.Out,0);
						},this);
					}
				}else{
					this.checkSpawnCustomer();
					this.text_jam.text= this.updateTime(this.game_time--);
					if(this.game_time<=0){
						callAudio(sfx_timeout,false,1);
						var twn = this.addTween(this.text_close,0,0,this.text_close.x+ratioXY(0),this.text_close.y+ratioXY(10),1000,Phaser.Easing.Quadratic.Out,0);
						twn.onComplete.addOnce(function(){
							this.text_close.y+=ratioXY(-20);
							this.text_close.text ='CLOSE';
							var twn2 = this.addTween(this.text_close,0,1,this.text_close.x+ratioXY(0),this.text_close.y+ratioXY(10),1000,Phaser.Easing.Quadratic.Out,0);
						},this);
					}
				}
			}else{
				var countCust =0;
				this.customers.forEachAlive(function(cust){
					if (cust.visible){
						countCust++;
					}
				},this);
				if (countCust==0){
					if (!this.filter_bg.visible)
						this.filter_bg.visible=true;
					if (this.filter_bg.alpha==0){
						this.filter_bg.alpha+=0.001;
						var twn = this.addTween(this.filter_bg,0,1,this.filter_bg.x,this.filter_bg.y,1000,Phaser.Easing.Quadratic.Out,1000);
						twn.onComplete.addOnce(function(){
							if (!this.group_result.visible){
								this.group_result.visible=true;
								this.filter_bg.visible=false;
								this.tweenResult(1);
							}
						},this);
					}
				}
			}
			this.checkRequestCustomer();
		}
	  }
	},

	render: function(){
	    if(this.flag_debug){
	       	game.debug.text("fps: "+game.time.fps,20,20);
	    }
	},	
};