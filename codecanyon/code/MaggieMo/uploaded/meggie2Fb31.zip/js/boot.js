if(NoesGames == null){	var NoesGames = {};}

NoesGames.bootState = function(game){
  //var lokal disini
}

NoesGames.bootState.prototype = {
	
	preload: function(){
	
	  var temp = "";
 
	  //if(!game.device.desktop){
	  //  temp = "/mobile";
	  //}	
	
	  game.load.image("preloadBg","assets/images"+temp+"/preload/bg.jpg");
	  game.load.image("preloadBar","assets/images"+temp+"/preload/bar_isi.png");
	  game.load.image("preloadBgBar","assets/images"+temp+"/preload/bar.png");
	
	},

	create: function(){

		//aktifkan physics system
		game.physics.startSystem(Phaser.Physics.P2JS);

		if(!game.device.desktop){
		  game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;		
		  game.scale.pageAlignHorizontally = true;
		  game.scale.pageAlignVertically = true;
	          game.scale.refresh();		  

	          game.scale.forceOrientation(true, true); 
		  
		  this.checkOrientation();
	  	  window.addEventListener("resize", this.checkOrientation, false);
		  window.addEventListener("orientationchange", this.checkOrientation, false);
		}
		else{
		  game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;		
		  game.scale.pageAlignHorizontally = true;
		  game.scale.pageAlignVertically = true;
	          game.scale.refresh();		
	          
	          document.body.style.backgroundImage = "url('assets/body_bg.png')";
		  
		  ////allowAds/////
		}		
		
		game.canvas.oncontextmenu = function (e) { e.preventDefault(); }
		
		game.state.start("preload");
	},
	
	checkOrientation: function()
	{
	  if(window.innerHeight < window.innerWidth) // > Portrait      < landscape
	  {
		rotate_msg = false;
		document.getElementById("turn").style.display="none";

		////allowAds/////
	  }	
	  else
	  {    		
		rotate_msg = true;
		document.getElementById("turn").style.display="block";

		////allowAds/////
	  }
        }

};