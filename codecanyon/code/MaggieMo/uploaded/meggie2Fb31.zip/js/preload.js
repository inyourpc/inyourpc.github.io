if(NoesGames == null){	var NoesGames = {};}

NoesGames.preloadState = function(game){
  //var lokal disini
  
  this.asset_ready = false;
  
  this.preloadBgBar = null;
  this.preloadBar = null;
}

NoesGames.preloadState.prototype = {

	preload: function(){
		//var preloadBg = game.add.sprite(0,0,"preloadBg");
		var preloadBg = game.add.button(game.world.centerX,game.world.centerY,"preloadBg",this.buttonPress,this,0,0,0);
		preloadBg.anchor.setTo(0.5);
		preloadBg.width = gameWidth;
		preloadBg.height = gameHeight;
		preloadBg.name = "FOG";
		
		this.preloadBgBar = game.add.sprite(game.world.centerX,game.world.height-ratioXY(60),"preloadBgBar");
		this.preloadBgBar.x -= this.preloadBgBar.width/2;
		this.preloadBgBar.anchor.setTo(0,0.5);
		this.preloadBar = game.add.sprite(game.world.centerX,game.world.height-ratioXY(60),"preloadBar");
		this.preloadBar.x -= this.preloadBar.width/2;
		this.preloadBar.anchor.setTo(0,0.5);
		
		game.load.setPreloadSprite(this.preloadBar,0); //0 horizontal 1 vertical
		
		//cara load sound
		//game.load.audio("bgm", ["assets/sounds/bgm.mp3"]);

		var temp = "";
		
		//if(!game.device.desktop){
		//  temp = "/mobile";
		//}		
		
		//cara load spritesheet
		game.load.atlasXML('sprites_game','assets/images'+temp+'/sprites_game.png','assets/images'+temp+'/sprites_game.xml');
		
		//cara load animasi sprite
		game.load.spritesheet("char1", "assets/images"+temp+"/spritesheet/char1(177x315).png", ratioXY(177), ratioXY(315));
		game.load.spritesheet("char2", "assets/images"+temp+"/spritesheet/char2(158x310).png", ratioXY(158), ratioXY(310));
		game.load.spritesheet("char3", "assets/images"+temp+"/spritesheet/char3(175x304).png", ratioXY(175), ratioXY(304));
		game.load.spritesheet("char4", "assets/images"+temp+"/spritesheet/char4(252x316).png", ratioXY(252), ratioXY(316));
		game.load.spritesheet("char5", "assets/images"+temp+"/spritesheet/char5(253x314).png", ratioXY(253), ratioXY(314));
		game.load.spritesheet("hati", "assets/images"+temp+"/spritesheet/hati(118x20).png", ratioXY(118), ratioXY(20));
				
		//cara load image
		game.load.image("bg_credit", "assets/images"+temp+"/bg_credit.jpg");
		game.load.image("filter", "assets/images"+temp+"/filter.png");
		
		game.load.image("logo2", "assets/images"+temp+"/logo.png");
		
		//cara load bitmap font
		game.load.bitmapFont('grobold', 'assets/fonts/grobold.png', 'assets/fonts/grobold.fnt');
		game.load.bitmapFont('putih_font', 'assets/fonts/putih_font.png', 'assets/fonts/putih_font.fnt');
		
		game.load.audio('bgm', ['assets/sounds/bgm.ogg','assets/sounds/bgm.mp3']);
		game.load.audio('ambil', ['assets/sounds/ambil.ogg','assets/sounds/ambil.mp3']);
		game.load.audio('benar', ['assets/sounds/benar.ogg','assets/sounds/benar.mp3']);
		game.load.audio('cash', ['assets/sounds/cash.ogg','assets/sounds/cash.mp3']);
		game.load.audio('come', ['assets/sounds/come.ogg','assets/sounds/come.mp3']);
		game.load.audio('gameover', ['assets/sounds/gameover.ogg','assets/sounds/gameover.mp3']);
		game.load.audio('kabur', ['assets/sounds/kabur.ogg','assets/sounds/kabur.mp3']);
		game.load.audio('klik', ['assets/sounds/klik.ogg','assets/sounds/klik.mp3']);
		game.load.audio('timeout', ['assets/sounds/timeout.ogg','assets/sounds/timeout.mp3']);
		game.load.audio('trash', ['assets/sounds/trash.ogg','assets/sounds/trash.mp3']);
		game.load.audio('win', ['assets/sounds/win.ogg','assets/sounds/win.mp3']);
	},

	create: function(){
		//this.preloadBgBar.visible = false;
		//this.preloadBar.visible = false;
	
		//var btn = game.add.button(game.world.centerX-ratioXY(200),game.world.height-ratioXY(270),"sprites_game",this.buttonPress,this,"play.png","play.png","play.png");
		//btn.anchor.setTo(0.5);
		//btn.name = "play";	
	},
	
	buttonPress : function(button, pointer, isOver){
		if(isOver)
		{
			if(button.name == "FOG"){
			  window.open('http://www.freeonlinegames.com');
			}
			
			//if(button.name == "play" && this.asset_ready == true){
			//  if(!game.device.desktop)
			//    callAudio(bgm,true,0.7);
			//  game.state.start("mainmenu");
			//}			
		}
	},	
	
	update: function(){
	
		if(game.cache.isSoundDecoded('bgm') && 
		   game.cache.isSoundDecoded('ambil') &&
		   game.cache.isSoundDecoded('benar') &&
		   game.cache.isSoundDecoded('cash') &&
		   game.cache.isSoundDecoded('come') &&
		   game.cache.isSoundDecoded('gameover') &&
		   game.cache.isSoundDecoded('kabur') &&
		   game.cache.isSoundDecoded('klik') &&
		   game.cache.isSoundDecoded('timeout') &&
		   game.cache.isSoundDecoded('trash') &&
		   game.cache.isSoundDecoded('win') &&
		   this.asset_ready == false)
		{
		  //this.preloadBgBar.visible = false;
		  //this.preloadBar.visible = false;
		  
		  this.asset_ready = true;
		
		  checkSupportSave();
		  
		  bgm = game.add.audio("bgm");
		  sfx_ambil = game.add.audio("ambil");
		  sfx_benar = game.add.audio("benar");
		  sfx_cash = game.add.audio("cash");
		  sfx_come = game.add.audio("come");
		  sfx_gameover = game.add.audio("gameover");
		  sfx_kabur = game.add.audio("kabur");
		  sfx_klik = game.add.audio("klik");
		  sfx_timeout = game.add.audio("timeout");
		  sfx_trash = game.add.audio("trash");
		  sfx_win = game.add.audio("win");
		  
		  checkSupportWebAudio();		  
		
		  //game.state.start("game");
		  game.state.start("mainmenu");				  		  		  			  		  		  
		}		
	}

};