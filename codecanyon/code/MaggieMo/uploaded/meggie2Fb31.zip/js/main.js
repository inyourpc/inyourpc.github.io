if(NoesGames == null){  var NoesGames = {};}

var gameWidth = 960; // the width of the game we want
var gameHeight = 640; // the height of the game we want

var flag_sound = true;
var flag_webAudio = true;

var flag_touchPlayAudio = false;

if (navigator.userAgent.match(/(iPhone|iPod|iPad|Android|BlackBerry|IEMobile)/)) {
  //console.log("MASUK");
  //gameWidth =  480;
  //gameHeight = 320;
  
  //flag_sound = false;  
  //flag_touchPlayAudio = true;
}

var bgm = null;
var sfx_ambil = null;
var sfx_benar =  null;
var sfx_cash =  null;
var sfx_come =  null;
var sfx_gameover = null;
var sfx_kabur = null;
var sfx_klik = null;
var sfx_timeout = null;
var sfx_trash = null;
var sfx_win = null;

var ratio = gameWidth/960;
var flag_debug=false;
var rotate_msg = false;

var level=1;//temp cuma dibuat game play
var maxlevel=8;//max level
var curlevel=1;//current level
var totalcoin =0;
var customerServed=0;
var totalBonus=0;
var flag_tutor =true;

//ads video
var flag_video = false;
var bonusCoin = 3;
var bonusCoinMin = 2;
var bonusCoinMax = 10;

var localStorageName = 'localStorage';
var saveName = "MeggieBreadRush";
var available_save = true;
var storage;
var objData = {};

var game = new Phaser.Game(gameWidth, gameHeight, Phaser.CANVAS);

game.state.add("boot", NoesGames.bootState);
game.state.add("preload", NoesGames.preloadState);
game.state.add("mainmenu", NoesGames.mainmenuState);
game.state.add("game", NoesGames.gameState);

game.state.start("boot");

function checkSupportWebAudio(){
   
   if(!game.device.desktop)
   {
     if(game.device.webAudio == false)
     {
       flag_webAudio = false;
     }
   }
   
}

function callAudio(audio, loop, vol)
{
  if(flag_sound)
  {
    if(loop == true)
    {
      audio.play("", 0, vol, true);
    }
    else
    {
      if(flag_webAudio)
        audio.play();
    }
  }
}

function callFadeToAudio(audio,ms,vol)
{
  if(flag_sound)
  {
    audio.fadeTo(ms,vol);
  }
}


function ratioXY(xy){
    return xy * ratio;//Math.floor( xy * ratio);
}

function global_sound_change(button){
    if (flag_sound) {
    
      if(flag_touchPlayAudio)
      {
        callAudio(bgm,true,0.7);
        flag_touchPlayAudio = false;
      }
      else
      {
          bgm.resume();
        }
        
        button.setFrames("sound_on.png", "sound_on.png", "sound_on.png");
    }else{
        bgm.pause();
        button.setFrames("sound_off.png", "sound_off.png", "sound_off.png");
    }
}

function global_sound(button){
    flag_sound = !flag_sound;
    global_sound_change(button);
}

/////////////////// fungsi save2an ////////////////////
function isLocalStorageNameSupported() {
  try {
     return (localStorageName in window && window[localStorageName]);
  } catch(e) {
     return false;
  }
}

function checkSupportSave() {
  //console.log("Check Data "+isLocalStorageNameSupported());

  if (isLocalStorageNameSupported()) {
    //console.log("Support Save Data");
    available_save = true;
    storage = window[localStorageName];           
  };                    
}

function checkData() {
  if(available_save == true)
  {
    if(JSON.parse(storage.getItem(saveName)) != null)
    {
      return true;
    }
    else
    {
      return false;           
    }
  }
}

function saveLoadData(tipe){
  
  try { 
  if(available_save == true)
  {
    if(tipe == 1) //save
    {     
      objData.curlevel= curlevel;
      objData.totalcoin =totalcoin;
      objData.customerServed =customerServed;
      objData.totalBonus = totalBonus;

      storage.setItem(saveName, JSON.stringify(objData));

      //console.log("SAVED DATA");
    }
    else
    if(tipe == 2) //load
    {
      if(checkData() == true)
      {  
        objData = JSON.parse(storage.getItem(saveName));

        curlevel = objData.curlevel;
        totalcoin = objData.totalcoin;
        customerServed = objData.customerServed;
        totalBonus = objData.totalBonus;
        //console.log("LOADED DATA");

      }
      else
      {
        //console.log("No Save Data!");
      }
    }
    else
    if(tipe == 3) //clear data
    {
      storage.clear();

      //console.log("CLEAR DATA");
    }
    
  }
    
  } catch (e) {
   
  //alert('You are in Private Browsing mode');
    
  }
}
///////////////////////////////////////////////////////

function P2TouchingObject(direction,player){

  var xAxis = p2.vec2.fromValues(1,0);
  var yAxis = p2.vec2.fromValues(0,1);
  var result = false;

  for (var i = 0; i < game.physics.p2.world.narrowphase.contactEquations.length; i++)
    {
        var c = game.physics.p2.world.narrowphase.contactEquations[i];

        if (c.bodyA === player.body.data || c.bodyB === player.body.data)
        {
            var dx = p2.vec2.dot(c.normalA, xAxis); 
            var dy = p2.vec2.dot(c.normalA, yAxis); // Normal dot Y-axis
            
            if(direction === "down")
            {
        if (c.bodyA === player.body.data) dy *= -1;
              if (dy > 0.5) result = true;              
            }
            else
      if(direction === "up")
            {
        if (c.bodyA === player.body.data) dy *= -1;
              if (dy < -0.5) result = true;             
            }
            else  
            if(direction === "left")
            {
        if (c.bodyA === player.body.data) dx *= -1;
              if (dx < 0) result = true;              
            }
            else            
            if(direction === "right")
            {
        if (c.bodyA === player.body.data) dx *= -1;
              if (dx > 0) result = true;              
            }
        }
    }
    
    return result;
}